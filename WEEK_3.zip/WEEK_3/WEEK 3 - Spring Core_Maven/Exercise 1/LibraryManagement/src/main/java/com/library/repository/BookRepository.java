package com.library.repository;

public class BookRepository {
	public void bookRepositoryShow()
	{
		System.out.println("Inside BookRepository");
	}
}
